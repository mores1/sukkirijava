# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'eb95eedff9e863d0ec0ab7a09ce14eff62ad916d57d2df625943b63b674fe7f744c261c134cbcf23441335f3f41a08afd74989da41ad109a914b39e7aff2e74d'